2026-10-14: sonnet session for grant_R_b024 wrote its output via a shell command (brief forbids commands); output voided and batch rerun in a fresh session.
