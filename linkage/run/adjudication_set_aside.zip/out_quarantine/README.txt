Quarantined 2026-10-25: Sonnet outputs for grant_N batches 117, 120-124. Reasons were templated
(item-specific reason share 0.01-0.07; e.g. "No candidate with compatible name and field." for 123/130 items)
and two sessions reported writing the file with a shell command, contrary to the brief. Decisions agreed with
Opus, but the item-level reasons required by protocol Section 6 were missing. Re-run in fresh sessions; these
files are kept for transparency and are not used.
